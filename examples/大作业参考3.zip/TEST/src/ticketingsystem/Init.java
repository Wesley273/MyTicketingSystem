package ticketingsystem;

//生成票，并且提供了很多构造方法
//介于无票和生成票中间的一种状态
public class Init {
	//定义所需属性和变量
    public int route, coach, seat, departure, arrival;

    //构造方法，初始化属性和变量
    //这里使用了构造方法重载。构造方法重载和方法重载很相似。可以为一个类创建多个构造方法。每一个构造方法必须有它自己唯一的参数列表。
    public Init(int route, int coach, int seat, int departure, int arrival) {
        this.route = route;
        this.coach = coach;
        this.seat = seat;
        this.departure = departure;
        this.arrival = arrival;
    }

    public Init(Ticket t) {
        this.route = t.route;
        this.coach = t.coach;
        this.seat = t.seat;
        this.departure = t.departure;
        this.arrival = t.arrival;
    }

    public Init(int route, int coach, int seat) {
        this.route = route;
        this.coach = coach;
        this.seat = seat;
    }

    //考虑到票数较多，所以使用long类型来定义票的编号
    public Ticket findTicket(long tid, String passenger) {
        Ticket t = new Ticket();
        t.tid = tid;
        t.passenger = passenger;
        t.route = route;
        t.coach = coach;
        t.seat = seat;
        t.departure = departure;
        t.arrival = arrival;
        return t;
    }
}