package ticketingsystem;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

import ticketingsystem.tools.BitHelper;
import ticketingsystem.tools.SectionRange;
import ticketingsystem.tools.bitoniccounter.BitonicCounter;

public class TicketingDS implements TicketingSystem {

	
	//////////定义变量
	private int routeNum = 5;//车次数目
	private int coachNum = 8;//每个车次的
	private int seatNum = 100;//每个车厢的座位数
	private int stationNum = 10;//车站数目
	private int threadNum = 16;//并发购票的线程数目
	private static final int try_num = 10;//回退阈值
	//Java可以设置回退阈值属性，以指定将消息交付至输入目标的尝试次数。
    //如果回退阈值设置为 0，那么不尝试重新交付。如果回退阈值为 1或更大值，那么将按指定次数重新交付消息。
	private BitonicCounter register;//计数器
	
	private SectionRange boundary;//区段范围

	private ConcurrentHashMap<Long, Ticket> list;
	//建立哈希表记录数据，record存放已经买到的票，买票给record增加数据，退票从record中删除数据
    //利用 ==CAS + synchronized== 来保证并发更新的安全
	//在进行读操作时(几乎)不需要加锁，而在写操作时通过锁分段技术只对所操作的段加锁而不影响客户端对其它段的访问。
	//特别地，在理想状态下，ConcurrentHashMap 可以支持 16 个线程执行并发写操作（如果并发级别设为16），及任意数量线程的读操作。
	
	
	////////初始化，并使用构造方法
	private void init_num() {
		register = new BitonicCounter((int) BitHelper.floor2power(threadNum));//使用位图法，使用计数器
		boundary = new SectionRange(routeNum, coachNum, seatNum, stationNum, threadNum);//创建区段实例
		int initialCapacity = (int) (routeNum * coachNum * seatNum * stationNum * 0.5);//车票总的保有量
		list = new ConcurrentHashMap<>(initialCapacity, 0.75f, threadNum);//建立哈希表的范围
	}

	//如果没有输入就按默认参数值，通过构造方法初始化
	public TicketingDS() {
		init_num();//初始化
	}

	//当java类实例化时，输入参数值，将属性初始化
	public TicketingDS(int routeNum, int coachNum, int seatNum, int stationNum, int threadNum) {
		this.routeNum = routeNum;
		this.coachNum = coachNum;
		this.seatNum = seatNum;
		this.stationNum = stationNum;
		this.threadNum = threadNum;
		init_num();
	}
    
	//购票方法
	public Ticket buyTicket(String passenger, int route, int departure, int arrival) {
		
		//随机选择一张票
		//ThreadLocalRandom并发地产生随机数，能够解决多个线程发生的竞争争夺。
		//ThreadLocalRandom不是直接用new实例化，而是第一次使用其静态方法current()。
		//不再有从多个线程访问同一个随机数生成器实例的争夺。取代以前每个随机变量实例化一个随机数生成器实例，我们可以每个线程实例化一个。
		ThreadLocalRandom number = ThreadLocalRandom.current();
		
		//调用Init，对构造方法输入具体参数，生成一个初始的票，为每一个调用随机的产生车厢号和座位号
		Init it = new Init(route, 0, 0, departure, arrival);
		//多次尝试，在回退次数内完成购票
		for (int i = 0; i < try_num; ++i) {//改？？
			it.coach = number.nextInt(coachNum) + 1;
			it.seat = number.nextInt(seatNum) + 1;
			if (demoTicket(it))//尝试购票
				return finishTicket(passenger, it);//完成购票
		}
		
		/*int j=0;
		while(!demoTicket(it)){
			j++;
			it.coach = number.nextInt(coachNum) + 1;
			it.seat = number.nextInt(seatNum) + 1;
		if(j==try_num){
				return null;
			}
		}
		return finishTicket(passenger, it);//完成购票
*/	
		//如果没有买到，判断是否空位？？
		List<Init> couldUse = boundary.locateAvailables(route, departure, arrival);
		//可能没有原子性
    	for (Init t : couldUse)//改？？
			if (demoTicket(t))//买的时候再验证
				return finishTicket(passenger, t);
		return null;
		
		
/*        int i = 0;
        while(!demoTicket(couldUse.get(i))){
        	i++;
        	if(i>couldUse.size())
        	{
        		return null;
        	}
        }
        return finishTicket(passenger, couldUse.get(i));
        */

	}


	//查询余票方法
	public int inquiry(int route, int departure, int arrival) {
		//查询余票
		return boundary.countAvailables(route, departure, arrival);
	}

	//退票方法
	//退票可以不加锁，直接将对应位置释放即可
	public boolean refundTicket(Ticket ticket) {
		if (ticket == null)
			return false;
		long tid = ticket.tid;
		//获取对应的票
		Init it = new Init(ticket);
		//判断是否合理
		if (boundary.isAvailable(it) || !list.containsKey(tid) || (list.remove(tid) == null))
			return false;
/*		if (list.remove(tid) == null)
			return false;*/
		//如果合理，则释放作为，完成退票并返回true
		boundary.free(it);
		return true;
	}

	//尝试购票
	private boolean demoTicket(Init it) {
		if (boundary.isAvailable(it)) {//判断对应的座位是否空闲
			try {
				boundary.lock(it);//上锁，避免多线程冲突
				if (!boundary.isAvailable(it))
					return false;
				boundary.occupy(it);//如果空闲则占用
				return true;
			} finally {
				boundary.unlock(it);//解锁
			}
		}
		return false;
	}

	//获得票的唯一编号tid，进行买票
	private Ticket finishTicket(String passenger, Init it) {
		//使用计数器购票，给他赋值id
		Ticket t = it.findTicket(register.getNext(), passenger);
		list.put(t.tid, t);
		return t;
	}
	

}

