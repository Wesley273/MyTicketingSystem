package ticketingsystem.tools;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import ticketingsystem.Init;

public class SectionRange {
    private Section[] sections;
    private int seatNum;
    private LocalHashMap hash;

    public SectionRange(int routeNum, int coachNum, int seatNum, int stationNum, int threadNum) {
        this.seatNum = seatNum;
        sections = new Section[stationNum - 1];
        for (int i = 0; i < sections.length; ++i)
            sections[i] = new Section(routeNum, coachNum, seatNum);
        hash = new LocalHashMap(routeNum, stationNum);
    }

    public void lock(Init it) {
        int s = it.departure - 1;
        int e = it.arrival - 1;
        for (int i = s; i < e; ++i)
            sections[i].lock(it.route, it.coach, it.seat);
    }

    public void unlock(Init it) {
        int s = it.departure - 1;
        int e = it.arrival - 1;
        for (int i = s; i < e; ++i)
            sections[i].unlock(it.route, it.coach, it.seat);
    }

    public boolean isAvailable(Init it) {
        boolean res = true;
        int s = it.departure - 1;
        int e = it.arrival - 1;
        for (int i = s; i < e; ++i) {
            res &= sections[i].isAvailable(it.route, it.coach, it.seat);
            if (res == false)
                return false;
        }
        return res;
    }

    public void occupy(Init it) throws IllegalStateException {
        int s = it.departure - 1;
        int e = it.arrival - 1;
        for (int i = s; i < e; ++i)
            sections[i].occupy(it.route, it.coach, it.seat);
    }

    public void free(Init it) throws IllegalStateException {
        int s = it.departure - 1;
        int e = it.arrival - 1;
        for (int i = s; i < e; ++i)
            sections[i].free(it.route, it.coach, it.seat);
    }

    private long[] getCompressedBitMap(int route, int departure, int arrival, boolean clear) {
        int s = departure;
        int e = arrival - 1;
        long[] bitMap = sections[s - 1].snapshot(route, clear);
        for (int i = s; i < e; ++i) {
            long[] bm = sections[i].snapshot(route, clear);
            assert bitMap.length == bm.length : "Length of route bitMap is different between sections";
            for (int j = 0; j < bitMap.length; ++j)
                bitMap[j] |= bm[j];
        }
        return bitMap;
    }

    private Init toInit(int index, int route, int departure, int arrival) {
        int seat = index % seatNum + 1;
        int coach = index / seatNum + 1;
        return new Init(route, coach, seat, departure, arrival);
    }

    public List<Init> locateAvailables(int route, int departure, int arrival) {
        ArrayList<Init> location = new ArrayList<>();
        long[] bitMap = getCompressedBitMap(route, departure, arrival, false);
        int size = Section.bitMapElementSize();
        for (int i = 0; i < bitMap.length; ++i) {
            List<Integer> l = BitHelper.locateZeros(bitMap[i]);
            for (int index : l)
                location.add(toInit(index + i * size, route, departure, arrival));
        }
        Collections.shuffle(location);
        return location;
    }

    public int countAvailables(int route, int departure, int arrival) {
        int availables = 0;
        int s = departure - 1;
        int e = arrival - 1;
        long[] bitMap = getCompressedBitMap(route, departure, arrival, true);
        boolean isChanged = false;
        for (int i = s; i < e; ++i) {
            if (isChanged)
                break;
            isChanged |= sections[i].isChanged();
        }
        if (isChanged || !hash.containsKey(route, departure, arrival)) {
            for (int i = 0; i < bitMap.length; ++i)
                availables += BitHelper.countZeros(bitMap[i]);
            hash.put(route, departure, arrival, availables);
        } else {
            availables = hash.get(route, departure, arrival);
        }
        return availables;
    }
}